
from src.projection.proj_fit import demo
Ostar,S,err = demo()
print("Recovered O* ~", Ostar, "S ~", S, "stderr ~", err)
