
from src.nuclear.shell_model_ufrf import degeneracy_and_magic, regression_checks
deg,mag = degeneracy_and_magic()
print("Degeneracy:", deg)
print("Magic:", mag)
print("Checks:", regression_checks())
