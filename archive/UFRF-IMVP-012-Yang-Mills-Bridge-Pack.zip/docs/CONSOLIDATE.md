
# CONSOLIDATE — IMVP‑012 Yang–Mills Bridge

- Keep this pack alongside IMVP‑011.
- Run: `python3 src/ym/toy_su2_field.py`.
- Store logs in `artifacts/ym_bridge.log` if you track artifacts.
- Cross‑map SU(2)×SU(2) to UFRF's 26 half‑spin substructure in the main text.
