
# CONSOLIDATE — IMVP‑020 PPN Tensor Cleanroom
- Place under `experiments/gravity/IMVP-020/`.
- Pin (A,B,B0) to explicit tensor expressions from UFRF invariants.
- Record safe ranges of Δp that satisfy Cassini/LLR bounds using the package’s stated limits.
