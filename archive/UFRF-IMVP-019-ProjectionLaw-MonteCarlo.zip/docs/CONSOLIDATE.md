
# CONSOLIDATE — IMVP‑019 Projection Law MC

- Place under `experiments/projection/`.
- Use to generate synthetic spreads for any observable after RG.
- Attach plots or summaries to your Projection appendix when ready.
