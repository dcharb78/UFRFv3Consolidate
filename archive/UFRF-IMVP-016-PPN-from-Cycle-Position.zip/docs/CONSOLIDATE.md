
# CONSOLIDATE — IMVP‑016 PPN from Cycle (Units-aware)

- Keep under `experiments/gravity/IMVP-016/` or similar.
- Use it to *bound* Δp and (a,b,B₀) choices by Cassini/LLR constraints recorded in the package.
- Record the chosen parameter window in your PPN derivation note.
