
# CONSOLIDATE — IMVP‑017 Near‑REST Abelianization

- Place under `experiments/gauge/`.
- Capture the ε‑scan output into `artifacts/abelianization_scan.log`.
- If R decreases with ε, note as *supportive* of near‑REST abelianization (still a toy model).
