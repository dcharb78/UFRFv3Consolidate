
# CONSOLIDATE — IMVP‑023 SU(3) Wilson Loops
- Place under `experiments/gauge/` alongside IMVP‑015.
- Record runs for period 13 and 26; compare FFT peaks and note robustness to seed/ε changes.
