
# CONSOLIDATE — IMVP‑011 Maxwell & Forms

- Place this folder at repo root (or anywhere).
- Run: `python3 scripts/maxwell_plane_wave_check.py`.
- Capture output under `artifacts/maxwell_demo.log` if you keep a repo log.
- Cross‑reference to UFRF geometry (E⊥B, REST) in your Core Theory write‑up.
