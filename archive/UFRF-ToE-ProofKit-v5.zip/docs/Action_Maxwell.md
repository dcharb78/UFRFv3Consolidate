
# Maxwell Action Notes

L = -1/4 F_{μν} F^{μν};  F_{μν} = ∂_μ A_ν - ∂_ν A_μ.
Euler–Lagrange → ∂_μ F^{μν} = J^{ν} (vacuum J=0), Bianchi ∂_[λ F_{μν]}=0.
