
# Yang–Mills Action Notes

L = -1/4 F^a_{μν} F^{a μν};  F^a_{μν} = ∂_μ A^a_ν - ∂_ν A^a_μ + g f^{abc} A^b_μ A^c_ν.
Vacuum EOM: D_μ F^{a μν} = 0; Bianchi: D_[λ F_{μν]} = 0.
