
# Current Status

- Maxwell & Dirac: green (action-level checks, numerics consistent).
- Yang–Mills: kinematics green; EOM gate in place; REST abelianization trend accessible.
  SU(3) fingerprints tested via multi-dimensional battery (torus chords, SU(2) subgroups, 2D FFT, characters).
- PPN: extractor + dynamics model ready; match to Cassini/LLR with your inputs.
- Projection law: fitter ready; apply to technique-split sets.
- Nuclear: degeneracy/magic sequences recovered; regression checks included.
