
# Dirac Action Notes

L = ψ̄ (i γ^μ ∂_μ - m) ψ; EOM (i γ^μ ∂_μ - m) ψ = 0.
Conserved current j^μ = ψ̄ γ^μ ψ, minimal coupling: ∂_μ → D_μ = ∂_μ + i e A_μ.
