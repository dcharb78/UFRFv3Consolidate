
# Next Steps

1) Run SU(3) multi-dimensional battery at Lmax=64 across seeds; decide Uphold/Constrain/Revise for 13/26 claim.
2) Run PPN extractor with your ephemerides; record (γ,β) + margin vs bounds; compare to dynamics means.
3) Fit Projection law on a real technique split (held-out validation).
4) Add small action plots (Bianchi residual vs step; YM ‖D_μF‖ vs REST knob).
