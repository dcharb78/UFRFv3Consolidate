
# PPN Dynamics: Recursive Resonance Model

γ(t), β(t) emerge from a recursive observer–observed loop (beats among cycles + small projection feedback).
Outputs: time-averaged ⟨γ⟩, ⟨β⟩; oscillation amplitudes; tail samples; convergence indicators.
