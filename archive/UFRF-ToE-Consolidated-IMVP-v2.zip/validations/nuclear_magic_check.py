
import os, sys, subprocess, json
# run the imported shell_model.py to standard out
print("Running nuclear shell_model.py ...")
