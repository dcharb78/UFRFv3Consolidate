
# Projection Law Calibration

- Fit ln O = ln O* + d_M α S + ε across technique slices.
- Validate on held-out technique; report residuals vs α and d_M. This is the cross-domain glue.
