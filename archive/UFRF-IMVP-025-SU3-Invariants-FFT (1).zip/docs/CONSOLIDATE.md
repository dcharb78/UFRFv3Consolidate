
# CONSOLIDATE — IMVP‑025 SU(3) Invariants & FFT
- Place under `experiments/gauge/`.
- Archive `artifacts/su3_invariants_fft.json` for periods 13 and 26.
- Compare FFT magnitudes around 1/13 and 1/26 indices to IMVP‑023 Wilson‑loop runs.
