
# CONSOLIDATE — IMVP‑024 SU(3) Near‑REST Abelianization

- Place under `experiments/gauge/`.
- Capture ε‑scan logs in `artifacts/su3_abelianization_scan.log`.
- A downward trend in R supports abelianization toward Cartan U(1)×U(1) near REST.
