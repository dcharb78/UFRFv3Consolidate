# UFRF-ToE (lightweight sandbox build)

Minimal structure for Maxwell/Dirac recovery tests.
