
def fractional_series_13(nmax=12):
    return [f"{k}/13" for k in range(1, nmax+1)]
