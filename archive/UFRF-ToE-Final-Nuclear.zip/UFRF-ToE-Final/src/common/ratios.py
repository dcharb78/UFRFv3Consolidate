
import math
def phi():
    return (1.0+5.0**0.5)/2.0
def sqrt_phi():
    return phi()**0.5
