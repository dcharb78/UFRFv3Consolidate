
import math
def beta_qed_one_loop(alpha, n_f=1):
    return 2.0*n_f/(3.0*math.pi) * alpha*alpha
