from __future__ import annotations

def anomaly_polynomials_stub():
    return {"U1^3": 0, "SU2^2U1": 0, "SU3^2U1": 0, "grav": 0}  # placeholders
