# Prereg — Sonoluminescence timing phase clustering
Metric: Rayleigh test p<0.01 for n/26 alignment.
