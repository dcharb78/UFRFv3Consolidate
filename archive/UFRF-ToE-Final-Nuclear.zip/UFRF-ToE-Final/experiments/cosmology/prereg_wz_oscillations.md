# Prereg — w(z) oscillations Δz≈1/13 around w*=-2/3

**Metric (pass/fail):** Cross‑validated periodogram peak at 1/13 ± 10%; leakage‑controlled.

**Notes:**
Public datasets only; blind folds; lock filters before unblinding.
