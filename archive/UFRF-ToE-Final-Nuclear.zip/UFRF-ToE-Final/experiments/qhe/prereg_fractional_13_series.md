# Prereg — QHE fractions at n/13 (enhanced at 10/13)

**Metric (pass/fail):** Plateau indices match n/13 more than chance; Holm‑Bonferroni corrected.

**Notes:**
Take mobilities > 10^7 cm^2/Vs; T < 0.5 K; B > 10 T.
