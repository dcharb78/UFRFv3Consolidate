# Prereg — Graphene η/s √φ enhancement
Metric: slope & data collapse under UFRF normalization.
