# Preregistration — Nuclear shell gap near 14.0±0.25 MeV

**Metric (pass/fail):** Detect discontinuity; Bayes factor > 10 vs uniform 1 MeV null.

**Notes:**
Freeze parameters before data; single analysis pass; hash datasets.
