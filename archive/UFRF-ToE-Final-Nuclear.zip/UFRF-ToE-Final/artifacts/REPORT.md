# WP‑B/C Smoke Report
- Hyperbolicity RMS (ω=k): 0.000e+00
- Hyperbolicity RMS (ω≠k): 2.005e-01
- Gauge invariance diffs: {'max_abs_diff_E': 5.655198531684391e-15, 'max_abs_diff_B': 0.0}
- Scalar mass (Lam=1, lam2=0.2, f=1): m²=304.200000, m=17.441330
