# WP‑B: Unitarity & Causality (Sketch Proof Notes)
- Gauge invariance: L built from F and *F invariants → Lorentz & gauge invariant.
- Constraint count (Maxwell): 2 first‑class constraints → 2 physical polarizations.
- Principal symbol around REST (I1=I2=0) matches Maxwell; disformal corrections small.
