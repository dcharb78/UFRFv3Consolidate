# Validation Kit

Reproduce repository results in a containerized, zero‑touch run.

## Usage
```bash
docker build -t ufrf-toe:latest .
docker run --rm -it ufrf-toe:latest ./run_all.sh
```
