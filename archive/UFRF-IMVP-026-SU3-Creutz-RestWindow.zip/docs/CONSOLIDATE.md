
# CONSOLIDATE — IMVP‑026 SU(3) Creutz & REST Window
- Place under `experiments/gauge/`.
- Record ε‑scan tables; decreasing mean χ as ε→0 supports UFRF REST→abelianization.
