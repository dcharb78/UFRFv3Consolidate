
# CONSOLIDATE — IMVP‑015 Wilson Loops & 13/26

- Place under `experiments/gauge/` (suggested).
- Run both 13 and 26 period scans and commit `artifacts/wilson_scan.json`.
- Cross‑reference results in your `theory/physics/YangMills.md` as the gauge‑invariant UFRF fingerprint test.
