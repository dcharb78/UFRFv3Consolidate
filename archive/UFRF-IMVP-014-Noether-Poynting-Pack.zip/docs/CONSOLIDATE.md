
# CONSOLIDATE — IMVP‑014 Noether & Poynting

- Run: `python3 scripts/poynting_plane_wave.py`.
- Archive outputs to `artifacts/poynting_demo.log` if tracking.
- Cross‑refer REST (E=B) and √φ efficiency language in your Integration Summary.
