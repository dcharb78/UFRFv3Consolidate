Run `python scripts/create_missing_inits.py <path-to-your-repo-root>` to add missing __init__ and derivation scaffolds.
