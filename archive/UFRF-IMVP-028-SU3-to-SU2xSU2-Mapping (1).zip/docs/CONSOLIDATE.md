
# CONSOLIDATE — IMVP‑028 SU(3) ↔ SU(2) Mapping
- Place under `experiments/gauge/`.
- Import `artifacts/su3_halfspin_map.json` to label SU(3) spectral and loop features with the UFRF 26 half‑spin indices.
- Cross‑reference with IMVP‑021 (SU(2)×SU(2) 26) for consistency of labels.
