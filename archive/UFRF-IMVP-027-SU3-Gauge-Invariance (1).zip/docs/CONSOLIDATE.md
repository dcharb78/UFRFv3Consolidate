
# CONSOLIDATE — IMVP‑027 Gauge Invariance Gate
- Place under `experiments/gauge/`.
- Record `rel_error` across L; values ≪ 1e‑10 confirm numerical gauge invariance for your grid.
- Gate SU(3) diagnostics: only proceed if this test passes.
