
# CONSOLIDATE — IMVP‑013 Gauge Projection & RG

- Execute: `python3 src/rg/run_couplings.py` to reproduce quick checks.
- Reference in text that projection is applied to **observables after RG**, not to intrinsic phases.
- Store outputs in `artifacts/rg_projection.log` if you keep artifact logs.
