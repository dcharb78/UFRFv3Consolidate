
# CONSOLIDATE — IMVP‑021
- Place under `experiments/gauge/`.
- Import `artifacts/su2xsu2_26.json` wherever you label spectral peaks or Wilson-loop features by half‑spin index.
- Cross‑link to the SU(2)×SU(2) → SO(4) notes in your math docs.
