# UFRF-IMVP-042 — Projection Law Calibration Kit

Fit the projection law parameters from multi-technique, multi-scale observations:
    ln O = ln O* + d_M · α · S + ε

- Synthetic generator + linear fit
- Drop-in functions for your real datasets
