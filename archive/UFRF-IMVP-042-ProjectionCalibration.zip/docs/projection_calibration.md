# Projection calibration steps

- Use `fit_projection` with your multi-technique dataset.
- Compare residuals vs technique to test α-dependence.
